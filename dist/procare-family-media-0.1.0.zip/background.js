"use strict";

importScripts("shared.js");

function isAuthorizedSender(sender) {
  try {
    const url = new URL(sender.tab && sender.tab.url || sender.url || "");
    return url.protocol === "https:" && url.hostname === "schools.procareconnect.com";
  } catch (_) {
    return false;
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "DOWNLOAD_MEDIA") return false;

  if (!isAuthorizedSender(sender)) {
    sendResponse({ ok: false, error: "Download request did not come from Procare." });
    return false;
  }

  if (!ProcareSafe.validateMediaUrl(message.url)) {
    sendResponse({ ok: false, error: "Procare supplied an invalid media URL." });
    return false;
  }

  const filename = String(message.filename || "")
    .split("/")
    .map((part) => ProcareSafe.sanitizeSegment(part, "media"))
    .join("/");

  chrome.downloads.download(
    {
      url: message.url,
      filename,
      conflictAction: "uniquify",
      saveAs: false
    },
    (downloadId) => {
      if (chrome.runtime.lastError || typeof downloadId !== "number") {
        sendResponse({
          ok: false,
          error: chrome.runtime.lastError ? chrome.runtime.lastError.message : "Chrome rejected the download."
        });
        return;
      }
      sendResponse({ ok: true, downloadId });
    }
  );

  return true;
});
